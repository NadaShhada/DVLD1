﻿namespace DVLD_DataAccess
{
  public  static class clsDataAccessSettings
    {
        public static string ConnectionString = "Server=.;Database=DVLD;User Id=sa;Password=sa123456;";


    }
}
