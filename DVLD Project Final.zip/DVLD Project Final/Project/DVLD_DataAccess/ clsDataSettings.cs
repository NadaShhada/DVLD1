using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneratSettings
{
    public class clsDataAccessSettings
    { 
        public static string ConnectionString = "Server=.;Database=DVLD;User Id=sa;Password=sa123456;";

 
    }
}
